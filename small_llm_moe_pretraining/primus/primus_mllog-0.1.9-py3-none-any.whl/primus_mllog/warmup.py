###############################################################################
# Copyright (c) 2025, Advanced Micro Devices, Inc. All rights reserved.
#
# See LICENSE for license information.
###############################################################################

"""Synthetic-data warmup for GPT-OSS-20B Primus/Megatron training.

Runs N forward+backward passes with random token sequences before the real
training loop starts.  This pre-compiles Triton / CK / hipBLASLt kernels so
the first real iteration doesn't pay the JIT cost.

After warmup:
  - Model parameters are restored from a pre-warmup snapshot.
  - Optimizer state is restored (neutered during warmup so weights never move).
  - LR scheduler state is rolled back.
  - FP8 scaling state (amax_history, scale, scale_inv, fp8_initialized) is
    fully reset and seeded with safe defaults.

Controlled by the SYNTH_WARMUP_STEPS env-var (default 3, 0 disables).
"""

import os
import sys
import time

import torch
import torch.distributed


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

def _log(msg):
    rank = torch.distributed.get_rank() if torch.distributed.is_initialized() else 0
    if rank == 0:
        print(f"[SYNTH_WARMUP] {msg}", flush=True)


# ---------------------------------------------------------------------------
# Synthetic data
# ---------------------------------------------------------------------------

class SyntheticGPTDataIterator:
    """Infinite iterator yielding random token batches for Primus/Megatron GPT.

    Primus's ``get_batch_on_this_tp_rank`` expects the iterator to yield a dict
    with ``tokens``, ``labels``, ``loss_mask``, and ``position_ids`` tensors,
    each of shape ``[mbs, seq_length]``.
    """

    def __init__(self, seq_length, micro_batch_size, vocab_size=32000):
        self.seq_length = seq_length
        self.micro_batch_size = micro_batch_size
        self.vocab_size = vocab_size

    def __iter__(self):
        return self

    def __next__(self):
        mbs = self.micro_batch_size
        sl = self.seq_length
        tokens = torch.randint(0, self.vocab_size, (mbs, sl), dtype=torch.int64)
        labels = torch.randint(0, self.vocab_size, (mbs, sl), dtype=torch.int64)
        loss_mask = torch.ones(mbs, sl, dtype=torch.float32)
        position_ids = torch.arange(sl, dtype=torch.int64).unsqueeze(0).expand(mbs, -1)
        return {
            "tokens": tokens,
            "labels": labels,
            "loss_mask": loss_mask,
            "position_ids": position_ids,
        }


# ---------------------------------------------------------------------------
# FP8 state management
# ---------------------------------------------------------------------------

def _manual_reset_fp8_meta(module):
    """Reset FP8 amax / scale tensors when reset_fp8_meta_tensors() is absent."""
    if not hasattr(module, "fp8_meta"):
        return False
    meta = module.fp8_meta
    reset_count = 0
    for key in ("scaling_fwd", "scaling_bwd"):
        if key not in meta:
            continue
        tensor_meta = meta[key]
        if hasattr(tensor_meta, "amax_history"):
            tensor_meta.amax_history.fill_(0.0)
            reset_count += 1
        if hasattr(tensor_meta, "scale"):
            tensor_meta.scale.fill_(1.0)
            reset_count += 1
        if hasattr(tensor_meta, "scale_inv"):
            tensor_meta.scale_inv.fill_(1.0)
            reset_count += 1
    return reset_count > 0


def reset_fp8_state(model, reset_meta_tensors=True):
    """Clear ``fp8_initialized`` on every TE layer, forcing re-init.

    When *reset_meta_tensors* is True, also zeros out amax_history and
    resets scale / scale_inv to 1.0.
    """
    count = 0
    method_count = 0
    manual_count = 0

    def _reset(m):
        nonlocal count, method_count, manual_count
        if hasattr(m, "fp8_initialized"):
            m.fp8_initialized = False
            count += 1
            if reset_meta_tensors:
                if hasattr(m, "reset_fp8_meta_tensors"):
                    m.reset_fp8_meta_tensors()
                    method_count += 1
                elif _manual_reset_fp8_meta(m):
                    manual_count += 1

    models = model if isinstance(model, (list, tuple)) else [model]
    for m in models:
        m.apply(_reset)
    _log(f"reset_fp8_state: {count} modules, "
         f"{method_count} via method, {manual_count} via manual reset")
    return count


def seed_fp8_amax(model, seed_value=1.0):
    """Fill amax_history with *seed_value* to prevent scale=inf after reset.

    Delayed scaling computes ``scale = fp8_max / max(amax_history)``.
    If amax_history is all-zero after reset, scale becomes inf -> NaN.
    Seeding with 1.0 gives scale = fp8_max / 1.0 ~ 448 (E4M3), which is safe.
    """
    count = 0

    def _seed(m):
        nonlocal count
        if not hasattr(m, "fp8_meta"):
            return
        meta = m.fp8_meta
        for key in ("scaling_fwd", "scaling_bwd"):
            if key not in meta:
                continue
            tensor_meta = meta[key]
            if hasattr(tensor_meta, "amax_history"):
                tensor_meta.amax_history.fill_(seed_value)
                count += 1

    models = model if isinstance(model, (list, tuple)) else [model]
    for m in models:
        m.apply(_seed)
    _log(f"seed_fp8_amax: seeded {count} amax_history tensors with {seed_value}")
    return count


# ---------------------------------------------------------------------------
# Optimizer save / restore
# ---------------------------------------------------------------------------

def _neuter_optimizer(optimizer):
    """Set betas=[1,1], weight_decay=0, bias_correction=False.

    With betas=[1,1] the Adam momentum/variance stays at its initial (zero)
    value, so the effective weight update is zero.
    """
    saved = []
    inner = getattr(optimizer, "optimizer", optimizer)
    for group in inner.param_groups:
        state = {}
        for key in ("betas", "weight_decay", "bias_correction", "pre_mult_wd"):
            if key in group:
                state[key] = group[key]
        saved.append(state)

        if "betas" in group:
            group["betas"] = [1.0, 1.0]
        if "weight_decay" in group:
            group["weight_decay"] = 0.0
        if "bias_correction" in group:
            group["bias_correction"] = False
        if "pre_mult_wd" in group:
            group["pre_mult_wd"] = 0.0
    return saved


def _restore_optimizer(optimizer, saved):
    inner = getattr(optimizer, "optimizer", optimizer)
    for group, state in zip(inner.param_groups, saved):
        for key, val in state.items():
            group[key] = val
        if "step" in group:
            del group["step"]


# ---------------------------------------------------------------------------
# Model parameter snapshot
# ---------------------------------------------------------------------------

def _save_model_params(models):
    """Snapshot all model parameters to CPU to avoid doubling GPU memory."""
    saved = {}
    for m in models:
        for name, p in m.named_parameters():
            saved[(id(m), name)] = p.data.to("cpu", copy=True)
    return saved


def _restore_model_params(models, saved):
    restored = 0
    for m in models:
        for name, p in m.named_parameters():
            key = (id(m), name)
            if key in saved:
                p.data.copy_(saved[key].to(p.device))
                restored += 1
    return restored


# ---------------------------------------------------------------------------
# LR scheduler save / restore
# ---------------------------------------------------------------------------

_SCHEDULER_KEYS = (
    "num_steps",
    "num_floating_point_operations_so_far",
)


def _save_scheduler_state(scheduler):
    if scheduler is None:
        return None
    return {k: getattr(scheduler, k) for k in _SCHEDULER_KEYS if hasattr(scheduler, k)}


def _restore_scheduler_state(scheduler, state):
    if scheduler is None or state is None:
        return
    for k, v in state.items():
        setattr(scheduler, k, v)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def run_synthetic_warmup(
    trainer,
    forward_step_func,
    model,
    optimizer,
    opt_param_scheduler,
    config,
    megatron_args,
):
    """Run *warmup_steps* forward+backward passes with synthetic data.

    Called from ``MLPerfMegatronPretrainTrainer.train()`` **before**
    ``RUN_START`` is logged, so warmup time is excluded from the timed run.
    All side-effects (model params, optimizer, LR scheduler, FP8 state)
    are fully reverted after warmup.

    Uses the Primus trainer's ``train_step`` (not upstream Megatron's) so
    that tuple-valued loss dicts are reduced correctly.
    """
    warmup_steps = int(os.getenv("SYNTH_WARMUP_STEPS", "3"))
    if warmup_steps <= 0:
        _log(f"Skipped (SYNTH_WARMUP_STEPS={warmup_steps})")
        return

    t0 = time.time()
    _log(f"Starting {warmup_steps}-step synthetic warmup "
         f"(seq_len={megatron_args.seq_length}, "
         f"mbs={megatron_args.micro_batch_size})")

    vocab_size = getattr(
        megatron_args, "padded_vocab_size",
        getattr(megatron_args, "vocab_size", 32000),
    )
    synth_iter = SyntheticGPTDataIterator(
        megatron_args.seq_length, megatron_args.micro_batch_size, vocab_size,
    )

    models = model if isinstance(model, (list, tuple)) else [model]

    # Temporarily set config fields needed by forward_backward_func.
    # Megatron's train() normally sets these, but warmup runs before it.
    from megatron.core.distributed import finalize_model_grads
    from megatron.core.distributed.distributed_data_parallel import (
        DistributedDataParallel as DDP,
    )
    saved_config = {}
    for key in ("finalize_model_grads_func", "grad_scale_func", "no_sync_func"):
        saved_config[key] = getattr(config, key, None)
    if config.finalize_model_grads_func is None:
        config.finalize_model_grads_func = finalize_model_grads
    if config.grad_scale_func is None:
        config.grad_scale_func = optimizer.scale_loss
    if megatron_args.overlap_grad_reduce and config.no_sync_func is None:
        if isinstance(models[0], DDP):
            config.no_sync_func = (
                models[0].no_sync if len(models) == 1
                else [m.no_sync for m in models]
            )

    # ---- save state -------------------------------------------------------
    _log(f"Saving {sum(p.numel() for m in models for p in m.parameters())} parameters")
    saved_params = _save_model_params(models)
    saved_opt = _neuter_optimizer(optimizer)
    saved_sched = _save_scheduler_state(opt_param_scheduler)

    # ---- warmup steps -----------------------------------------------------
    for step in range(1, warmup_steps + 1):
        step_t0 = time.time()
        trainer.train_step(
            forward_step_func, synth_iter, model,
            optimizer, opt_param_scheduler, config,
        )
        torch.cuda.synchronize()
        _log(f"Step {step}/{warmup_steps} done in {time.time() - step_t0:.1f}s")

    # ---- restore state ----------------------------------------------------
    _log("Restoring optimizer")
    _restore_optimizer(optimizer, saved_opt)

    _log("Restoring LR scheduler")
    _restore_scheduler_state(opt_param_scheduler, saved_sched)

    _log("Restoring model parameters")
    n_restored = _restore_model_params(models, saved_params)
    del saved_params
    _log(f"Restored {n_restored} parameter tensors")

    if hasattr(optimizer, "reload_model_params"):
        optimizer.reload_model_params()
        _log("Called optimizer.reload_model_params()")

    # ---- reset FP8 --------------------------------------------------------
    _log("Resetting FP8 state")
    total_reset = 0
    for m in models:
        total_reset += reset_fp8_state(m, reset_meta_tensors=True)
    seed_fp8_amax(models, seed_value=1.0)

    # ---- release cached allocator blocks so VRAM returns to pre-warmup level
    torch.cuda.synchronize()
    torch.cuda.empty_cache()
    if torch.distributed.is_initialized():
        torch.distributed.barrier()

    # ---- restore config -------------------------------------------------------
    for key, val in saved_config.items():
        setattr(config, key, val)

    nan_params = sum(
        1 for m in models for _, p in m.named_parameters()
        if p.data.is_floating_point() and torch.isnan(p.data).any()
    )
    elapsed = time.time() - t0
    _log(f"Warmup complete in {elapsed:.1f}s  "
         f"(reset {total_reset} FP8 modules, nan_params={nan_params})")
